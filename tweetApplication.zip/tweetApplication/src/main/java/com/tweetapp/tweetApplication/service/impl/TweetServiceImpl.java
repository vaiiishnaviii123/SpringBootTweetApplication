package com.tweetapp.tweetApplication.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.tweetapp.tweetApplication.dao.TweetDao;
import com.tweetapp.tweetApplication.model.Tweet;
import com.tweetapp.tweetApplication.service.TweetService;

public class TweetServiceImpl implements TweetService {

	@Autowired
	TweetDao tweetDao;

	@Override
	public Tweet newTweet(String message, String emailId) {

		Tweet tweet = new Tweet();
		
		tweet.setEmailId(emailId);
		tweet.setTweetMessage(message);
		
		return tweetDao.addTweet(tweet);
		
	}

	@Override
	public List<Tweet> viewUsersTweets(String emailId) {
		
		return tweetDao.getUserAllTweets(emailId);
		
	}

	@Override
	public List<Tweet> viewAllTweets() {
		
		return tweetDao.getAllTweets();
	}
}
