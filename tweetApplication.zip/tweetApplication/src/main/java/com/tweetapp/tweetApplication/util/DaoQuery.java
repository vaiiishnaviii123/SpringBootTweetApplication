package com.tweetapp.tweetApplication.util;

public class DaoQuery {

	public static final String QUERY_UPDATE_PASSWORD = "UPDATE tweetApp.User SET password=? where emailId=? ";

}
