package com.tweetapp.tweetApplication.repository;


import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.tweetapp.tweetApplication.model.User;

@Repository
@Transactional
public interface UserRepository extends JpaRepository<User, String>{
	
//	List<Tweet> findTweetByUserId(String emailId);
	
//	User findByEmailId(String emailId);
//	
//	@Transactional
//	@Modifying
//	@Query(value= DaoQuery.QUERY_UPDATE_PASSWORD, nativeQuery = true)
//	Integer updateUserPassowrd(String emailId, String password);

}
