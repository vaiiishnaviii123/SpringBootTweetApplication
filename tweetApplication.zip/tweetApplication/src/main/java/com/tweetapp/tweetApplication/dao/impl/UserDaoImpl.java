package com.tweetapp.tweetApplication.dao.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.tweetApplication.dao.UserDao;
import com.tweetapp.tweetApplication.model.User;
import com.tweetapp.tweetApplication.repository.TweetRepository;
import com.tweetapp.tweetApplication.repository.UserRepository;

@Service
@Transactional
public class UserDaoImpl implements UserDao{
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public User registerNewUser(User user) {
		System.out.println("inside dao impl");		
		return userRepository.save(user);
	}

	@Override
	public Integer userLogin(String emailId, String password) {
		
		Integer result = 0;
		User user = userRepository.findByEmailId(emailId);
		
		if(user.getPassword().equals(password)) {
			result = 1;
		}
		
		return result;
	}

	@Override
	public Integer changePassword(String emailId, String oldPassword, String newPassword) {
	
		User user = userRepository.findByEmailId(emailId);
		Integer result = 0;
		
		if(user.getPassword().equals(oldPassword)) {
			
			result = userRepository.updateUserPassowrd(emailId, newPassword);
		}
		
		return result;
	}

	@Override
	public List<User> getAllUsers() {
		
		return userRepository.findAll();
	}

	@Override
	public User getUserByUserId(String emailId) {
		
		return userRepository.findByEmailId(emailId);
	}

	@Override
	public User userLogout(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
