package com.tweetapp.tweetApplication.service;

import java.util.List;

import com.tweetapp.tweetApplication.model.User;

public interface UserService {

	User registerNewUser(User user);
	Integer userLogin(String emailId,String password);
	Integer changePassword(String emailId, String oldPassword, String newPassword);
	User getUserByUserId(String emailId);
	List<User> getAllUsers();
	User userLogout(User user);
}
