package com.tweetapp.tweetApplication.service;

import java.util.List;

import com.tweetapp.tweetApplication.model.Tweet;

public interface TweetService {
	
	Tweet newTweet(String tweet, String emailId);
	List<Tweet> viewUsersTweets(String emailId);
	List<Tweet> viewAllTweets();

}
